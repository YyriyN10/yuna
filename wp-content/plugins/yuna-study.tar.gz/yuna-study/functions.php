<?php

	if ( ! defined( 'ABSPATH' ) ) {
		exit; // Don't access directly.
	};

	function yunaActivation(){
		$site = get_home_url();

		wp_mail('1987elessar@gmail.com', 'Plugin activation', "Plugin work in {$site}");
	}

	function yunaDeactivation(){
		file_put_contents( YUNA_STUDY_DIR . 'log.txt', 'Plugin deactivation. ', FILE_APPEND);
	}