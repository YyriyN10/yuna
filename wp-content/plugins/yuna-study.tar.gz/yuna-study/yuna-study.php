<?php

	/*
	 * Plugin Name: Yuna Stydy
	 * Plugin URI: https://yuna.com.ua
	 * Description: A plugin that impliments Yuna Functionality;
	 * Version: 1.0.0
	 * Author: Yuriy Naiden
	 * Author URI: https://yuna.com.ua
	 * License: GPLv2 or later
	 * Text Domain: yuna-core
	 */

	if ( ! defined( 'ABSPATH' ) ) {
		exit; // Don't access directly.
	};

	define ('YUNA_STUDY_DIR', plugin_dir_path(__FILE__));

	require YUNA_STUDY_DIR . 'functions.php';

	register_activation_hook(__FILE__, 'yunaActivation');

	register_deactivation_hook(__FILE__,'yunaDeactivation');