<?php

	if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
		exit; // Don't access directly.
	};

