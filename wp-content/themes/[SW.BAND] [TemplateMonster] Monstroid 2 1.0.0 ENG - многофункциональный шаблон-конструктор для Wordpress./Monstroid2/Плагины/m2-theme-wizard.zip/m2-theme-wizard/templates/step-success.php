<h2><?php esc_html_e( 'The theme is successfully installed', 'm2-theme-wizard' ); ?></h2>
<div class="desc"><?php
	esc_html_e( 'Congratulations, your theme is successfully installed!', 'm2-theme-wizard' );
?></div>