<?php
/**
 * Page footer template
 */
?>
	</div>
</div>

<?php do_action( 'ttw_main_after' ); ?>
