<?php
/**
 * Wizard page header template
 */
?>
<div class="wrap">
	<div class="m2-theme-wizard">
