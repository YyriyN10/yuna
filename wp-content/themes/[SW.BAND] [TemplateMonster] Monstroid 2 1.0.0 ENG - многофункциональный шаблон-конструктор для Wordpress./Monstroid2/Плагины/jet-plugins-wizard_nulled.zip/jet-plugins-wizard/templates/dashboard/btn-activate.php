<?php
/**
 * Activate button template
 */
?>
<button data-action="activate" class="wizard-plugin__activate wizard-plugin__link"><span class="text"><?php
		esc_html_e( 'Activate', 'jet-plugins-wizard' );
	?></span><span class="jet-plugins-wizard-loader"><span class="jet-plugins-wizard-loader__spinner"></span></span>
</buttom>