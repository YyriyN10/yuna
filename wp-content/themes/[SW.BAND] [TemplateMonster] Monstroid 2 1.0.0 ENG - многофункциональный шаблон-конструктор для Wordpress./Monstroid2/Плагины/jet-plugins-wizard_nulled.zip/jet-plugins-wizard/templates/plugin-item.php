<?php
/**
 * Plugin item template
 */
?>
<div class="jet-plugins-wizard-item" data-plugin="%1$s">
	%3$s
	<div class="jet-plugins-wizard-item__label"><?php esc_html_e( 'Install Plugin', 'jet-plugins-wizard' ); ?>: <b>%2$s</b></div>
</div>