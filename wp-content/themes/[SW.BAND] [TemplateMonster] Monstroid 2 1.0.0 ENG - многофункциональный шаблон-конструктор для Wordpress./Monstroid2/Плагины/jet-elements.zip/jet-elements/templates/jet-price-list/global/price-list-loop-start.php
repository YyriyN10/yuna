<?php
/**
 * Price list start template
 */
?>
<ul class="jet-price-list">