<?php
/**
 * Sale badge template
 */

woocommerce_show_product_sale_flash();
