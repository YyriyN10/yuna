<?php
/**
 * Single rating template
 */

woocommerce_template_single_rating();
