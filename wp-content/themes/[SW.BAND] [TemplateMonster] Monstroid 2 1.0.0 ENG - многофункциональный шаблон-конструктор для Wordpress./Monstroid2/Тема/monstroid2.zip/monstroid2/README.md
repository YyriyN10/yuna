# Monstroid2
Monstroid2 - truely multipurpose WordPress theme for real life projects. Built with love and care by Zemez.

## Changelog

### 1.0.0
- SYS: init